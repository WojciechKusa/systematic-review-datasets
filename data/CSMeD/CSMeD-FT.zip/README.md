Dataset version: 1.0.0
License: CC BY 4.0
Date: 2023-06-01